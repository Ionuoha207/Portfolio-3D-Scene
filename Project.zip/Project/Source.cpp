﻿#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <iostream>
#include <cmath>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

const char* vertexShaderSource = R"(
    #version 330 core
    layout (location = 0) in vec3 aPos;
    layout (location = 1) in vec2 aTexCoords;
    layout (location = 2) in vec3 aNormal;

    out vec2 TexCoords;
    out vec3 FragPos;
    out vec3 Normal;

    uniform mat4 model;
    uniform mat4 view;
    uniform mat4 projection;

    void main()
    {
        FragPos = vec3(model * vec4(aPos, 1.0));
        Normal = mat3(transpose(inverse(model))) * aNormal;  
        gl_Position = projection * view * vec4(FragPos, 1.0);
        TexCoords = aTexCoords;
    }
)";

const char* fragmentShaderSource = R"(
    #version 330 core
    in vec2 TexCoords;
    in vec3 FragPos;
    in vec3 Normal;

    out vec4 FragColor;

    struct Material {
        sampler2D diffuse;
        sampler2D specular;
        float shininess;
    }; 

    struct Light {
        vec3 direction;
        vec3 ambient;
        vec3 diffuse;
        vec3 specular;
    };

    uniform Material material;
    uniform Light light;

    void main()
    {
        // Ambient
        vec3 ambient = light.ambient * texture(material.diffuse, TexCoords).rgb;

        // Diffuse
        vec3 norm = normalize(Normal);
        vec3 lightDir = normalize(-light.direction);
        float diff = max(dot(norm, lightDir), 0.0);
        vec3 diffuse = light.diffuse * (diff * texture(material.diffuse, TexCoords).rgb);

        // Specular
        vec3 viewDir = normalize(-FragPos);
        vec3 reflectDir = reflect(-lightDir, norm);
        float spec = pow(max(dot(viewDir, reflectDir), 0.0), material.shininess);
        vec3 specular = light.specular * (spec * texture(material.specular, TexCoords).rgb);

        vec3 result = ambient + diffuse + specular;
        FragColor = vec4(result, 1.0);
    }
)";

// Camera settings
glm::vec3 cameraPos = glm::vec3(1.0f, 1.0f, 2.0f);
glm::vec3 cameraFront = glm::vec3(0.0f, 0.0f, -1.0f);
glm::vec3 cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);
float cameraSpeed = 2.5f;
float mouseSensitivity = 0.1f;
float cameraYaw = -90.0f;
float cameraPitch = 0.0f;
float cameraFOV = 45.0f;
bool orthographic = false;

// Mouse input variables
bool firstMouse = true;
float lastX = 400.0f;
float lastY = 300.0f;

// Callback function to handle window resizing
void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}

// Process user input
void processInput(GLFWwindow* window)
{
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    float cameraSpeed = 2.5f * glfwGetTime();
    glfwSetTime(0.0);

    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        cameraPos += cameraSpeed * cameraFront;
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        cameraPos -= cameraSpeed * cameraFront;
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        cameraPos -= glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        cameraPos += glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
        cameraPos += cameraSpeed * cameraUp;
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
        cameraPos -= cameraSpeed * cameraUp;
    if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS && glfwGetTime() > 0.2)
    {
        orthographic = !orthographic;
        glfwSetTime(0.0);
    }
}

// Callback function to handle mouse movement
void mouse_callback(GLFWwindow* window, double xpos, double ypos)
{
    if (firstMouse)
    {
        lastX = xpos;
        lastY = ypos;
        firstMouse = false;
    }

    float xoffset = xpos - lastX;
    float yoffset = lastY - ypos;

    lastX = xpos;
    lastY = ypos;

    xoffset *= mouseSensitivity;
    yoffset *= mouseSensitivity;

    cameraYaw += xoffset;
    cameraPitch += yoffset;

    if (cameraPitch > 89.0f)
        cameraPitch = 89.0f;
    if (cameraPitch < -89.0f)
        cameraPitch = -89.0f;

    glm::vec3 front;
    front.x = cos(glm::radians(cameraYaw)) * cos(glm::radians(cameraPitch));
    front.y = sin(glm::radians(cameraPitch));
    front.z = sin(glm::radians(cameraYaw)) * cos(glm::radians(cameraPitch));
    cameraFront = glm::normalize(front);
}

// Callback function to handle mouse scroll
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset)
{
    cameraSpeed += static_cast<float>(yoffset);
    if (cameraSpeed < 0.1f)
        cameraSpeed = 0.1f;
    if (cameraSpeed > 10.0f)
        cameraSpeed = 10.0f;
}

// Callback function to handle keyboard input
void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_P && action == GLFW_PRESS)
    {
        orthographic = !orthographic;  // Toggle between perspective and orthographic
    }
}

int main()
{
    // Initialize GLFW
    if (!glfwInit())
    {
        std::cerr << "Failed to initialize GLFW" << std::endl;
        return -1;
    }

    // Specify OpenGL version
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);

    // Create a GLFW window
    GLFWwindow* window = glfwCreateWindow(800, 600, "3D Scene", NULL, NULL);
    if (!window)
    {
        std::cerr << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return -1;
    }

    // Set keyboard callback function
    glfwSetKeyCallback(window, key_callback);

    // Make the window's context current
    glfwMakeContextCurrent(window);

    // Set framebuffer size callback
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);

    // Set mouse callback
    glfwSetCursorPosCallback(window, mouse_callback);

    // Set scroll callback
    glfwSetScrollCallback(window, scroll_callback);

    // Disable cursor
    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    // Initialize GLAD
    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
    {
        std::cerr << "Failed to initialize GLAD" << std::endl;
        return -1;
    }

    // Enable depth testing
    glEnable(GL_DEPTH_TEST);

    // Disable transparency
    glDisable(GL_BLEND);

    // Compile vertex shader
    unsigned int vertexShader;
    vertexShader = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vertexShader, 1, &vertexShaderSource, NULL);
    glCompileShader(vertexShader);

    // Compile fragment shader
    unsigned int fragmentShader;
    fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fragmentShader, 1, &fragmentShaderSource, NULL);
    glCompileShader(fragmentShader);

    // Link shaders
    unsigned int shaderProgram;
    shaderProgram = glCreateProgram();
    glAttachShader(shaderProgram, vertexShader);
    glAttachShader(shaderProgram, fragmentShader);
    glLinkProgram(shaderProgram);
    glUseProgram(shaderProgram);

    const float a = 0.55f;  // semi-major axis
    const float b = 0.35f;  // semi-minor axis
    const float h = 0.02f; // height (thickness) of the plate
    const int numSegments = 100; // Number of segments to approximate the ellipse

    // Define table vertices
    float tableVertices[] = {
        // Tabletop (rectangle)
        -0.5f, 0.0f, -0.3f,  0.0f, 0.0f, 0.0f, 1.0f, 0.0f,  // Position, TexCoords, Normals
         0.5f, 0.0f, -0.3f,  1.0f, 0.0f, 0.0f, 1.0f, 0.0f,
         0.5f, 0.0f,  0.3f,  1.0f, 1.0f, 0.0f, 1.0f, 0.0f,
        -0.5f, 0.0f,  0.3f,  0.0f, 1.0f, 0.0f, 1.0f, 0.0f,

        // Table legs (cubes)
        // Front left leg 
        -0.42f, -0.42f, -0.22f,  0.0f, 0.0f, 0.0f, 0.0f, -1.0f,
        -0.33f, -0.42f, -0.22f,  1.0f, 0.0f, 0.0f, 0.0f, -1.0f,
        -0.33f, 0.0f, -0.22f,  1.0f, 1.0f, 0.0f, 0.0f, -1.0f,
        -0.42f, 0.0f, -0.22f,  0.0f, 1.0f, 0.0f, 0.0f, -1.0f,
        // Front right leg 
        0.33f, -0.42f, -0.22f,  0.0f, 0.0f, 0.0f, 0.0f, -1.0f,
        0.42f, -0.42f, -0.22f,  1.0f, 0.0f, 0.0f, 0.0f, -1.0f,
        0.42f, 0.0f, -0.22f,  1.0f, 1.0f, 0.0f, 0.0f, -1.0f,
        0.33f, 0.0f, -0.22f,  0.0f, 1.0f, 0.0f, 0.0f, -1.0f,
        // Back right leg 
        0.33f, -0.42f, 0.22f,  0.0f, 0.0f, 0.0f, 0.0f, -1.0f,
        0.42f, -0.42f, 0.22f,  1.0f, 0.0f, 0.0f, 0.0f, -1.0f,
        0.42f, 0.0f, 0.22f,  1.0f, 1.0f, 0.0f, 0.0f, -1.0f,
        0.33f, 0.0f, 0.22f,  0.0f, 1.0f, 0.0f, 0.0f, -1.0f,
        // Back left leg 
        -0.42f, -0.42f, 0.22f,  0.0f, 0.0f, 0.0f, 0.0f, -1.0f,
        -0.33f, -0.42f, 0.22f,  1.0f, 0.0f, 0.0f, 0.0f, -1.0f,
        -0.33f, 0.0f, 0.22f,  1.0f, 1.0f, 0.0f, 0.0f, -1.0f,
        -0.42f, 0.0f, 0.22f,  0.0f, 1.0f, 0.0f, 0.0f, -1.0f,
    };

    // Define plate vertices 
    float plateVertices[(numSegments + 1) * 8]; // 8 attributes per vertex
    float angleIncrement = 2 * glm::pi<float>() / numSegments;
    int vertexIndex = 0;

    for (int i = 0; i <= numSegments; ++i) {
        float angle = i * angleIncrement;
        float x = a * cos(angle);
        float z = b * sin(angle);

        // Adjust the y-coordinate (elevation) for each vertex to make the plate more like a bowl
        float elevation = 0.1 * (x * x + z * z); // You can adjust the factor (0.1) to control the depth of the bowl

        // Vertex position with elevation
        plateVertices[vertexIndex++] = x;
        plateVertices[vertexIndex++] = elevation;
        plateVertices[vertexIndex++] = z;

        // Texture coordinates
        plateVertices[vertexIndex++] = static_cast<float>(i) / numSegments;
        plateVertices[vertexIndex++] = 0.5f; // V-coordinate

        // Normals
        plateVertices[vertexIndex++] = 0.0f;
        plateVertices[vertexIndex++] = 1.0f;
        plateVertices[vertexIndex++] = 0.0f;
    }


    // Define table indices
    unsigned int tableIndices[] = {
        // Tabletop (two triangles)
        0, 1, 2,
        0, 2, 3,

        // Legs (cubes, 6 faces each)
        // Front left leg
        4, 5, 6,
        4, 6, 7,
        // Front right leg
        8, 9, 10,
        8, 10, 11,
        // Back right leg
        12, 13, 14,
        12, 14, 15,
        // Back left leg
        16, 17, 18,
        16, 18, 19,
    };

    unsigned int plateVAO, plateVBO;
    glGenVertexArrays(1, &plateVAO);
    glGenBuffers(1, &plateVBO);
    glBindVertexArray(plateVAO);
    glBindBuffer(GL_ARRAY_BUFFER, plateVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(plateVertices), plateVertices, GL_STATIC_DRAW);

    // Specify vertex attributes
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
    glEnableVertexAttribArray(2);

    // Vertex Buffer Object (VBO)
    unsigned int VBO;
    glGenBuffers(1, &VBO);
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(tableVertices), tableVertices, GL_STATIC_DRAW);

    // Vertex Array Object (VAO)
    unsigned int VAO;
    glGenVertexArrays(1, &VAO);
    glBindVertexArray(VAO);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(5 * sizeof(float)));
    glEnableVertexAttribArray(2);

    // Element Buffer Object (EBO)
    unsigned int EBO;
    glGenBuffers(1, &EBO);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(tableIndices), tableIndices, GL_STATIC_DRAW);

    // Projection matrix
    glm::mat4 projection = glm::perspective(glm::radians(45.0f), 800.0f / 600.0f, 0.1f, 100.0f);
    glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "projection"), 1, GL_FALSE, glm::value_ptr(projection));

    unsigned int tableTexture;
    glGenTextures(1, &tableTexture);
    glBindTexture(GL_TEXTURE_2D, tableTexture);

    // Set texture wrapping and filtering options for the table top texture
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    int width, height, nrChannels;
    unsigned char* data = stbi_load("real.jpg", &width, &height, &nrChannels, 0);
    if (data)
    {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
        glGenerateMipmap(GL_TEXTURE_2D);
    }
    else
    {
        std::cerr << "Failed to load table texture" << std::endl;
        return -1;
    }
    stbi_image_free(data);

    unsigned int legsTexture;
    glGenTextures(1, &legsTexture);
    glBindTexture(GL_TEXTURE_2D, legsTexture);

    // Set texture wrapping and filtering options for the legs texture
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    data = stbi_load("material.jpg", &width, &height, &nrChannels, 0);
    if (data)
    {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
        glGenerateMipmap(GL_TEXTURE_2D);
    }
    else
    {
        std::cerr << "Failed to load legs texture" << std::endl;
        return -1;
    }
    stbi_image_free(data);

    unsigned int plateTexture;
    glGenTextures(1, &plateTexture);
    glBindTexture(GL_TEXTURE_2D, plateTexture);

    // Set texture wrapping and filtering options for the plate texture
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    data = stbi_load("plate_texture.jpg", &width, &height, &nrChannels, 0);
    if (data)
    {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
        glGenerateMipmap(GL_TEXTURE_2D);
    }
    else
    {
        std::cerr << "Failed to load plate texture" << std::endl;
        return -1;
    }
    stbi_image_free(data);

    // Lighting properties
    glm::vec3 lightDirection(-1.0f, -1.0f, -1.0f);
    glm::vec3 lightAmbient(0.4f, 0.4f, 0.4f);
    glm::vec3 lightDiffuse(0.8f, 0.8f, 0.8f);
    glm::vec3 lightSpecular(1.5f, 1.5f, 1.5f);

    // Material properties
    GLint materialDiffuseLoc = glGetUniformLocation(shaderProgram, "material.diffuse");
    GLint materialSpecularLoc = glGetUniformLocation(shaderProgram, "material.specular");
    GLint materialShininessLoc = glGetUniformLocation(shaderProgram, "material.shininess");
    glUniform1i(materialDiffuseLoc, 0);  // Set diffuse texture to unit 0
    glUniform1i(materialSpecularLoc, 1); // Set specular texture to unit 1
    glUniform1f(materialShininessLoc, 32.0f);

    // Lighting properties
    GLint lightDirectionLoc = glGetUniformLocation(shaderProgram, "light.direction");
    GLint lightAmbientLoc = glGetUniformLocation(shaderProgram, "light.ambient");
    GLint lightDiffuseLoc = glGetUniformLocation(shaderProgram, "light.diffuse");
    GLint lightSpecularLoc = glGetUniformLocation(shaderProgram, "light.specular");
    glUniform3fv(lightDirectionLoc, 1, glm::value_ptr(lightDirection));
    glUniform3fv(lightAmbientLoc, 1, glm::value_ptr(lightAmbient));
    glUniform3fv(lightDiffuseLoc, 1, glm::value_ptr(lightDiffuse));
    glUniform3fv(lightSpecularLoc, 1, glm::value_ptr(lightSpecular));

    while (!glfwWindowShouldClose(window))
    {
        processInput(window);

        // Clear the color buffer and depth buffer
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        // Update projection matrix based on the chosen view (perspective or orthographic)
        glm::mat4 projection;
        if (orthographic) {
            // Set up orthographic projection
            projection = glm::ortho(-2.0f, 2.0f, -2.0f, 2.0f, 0.1f, 100.0f);
        }
        else {
            // Set up perspective projection
            projection = glm::perspective(glm::radians(45.0f), 800.0f / 600.0f, 0.1f, 100.0f);
        }
        glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "projection"), 1, GL_FALSE, glm::value_ptr(projection));

        // View matrix
        glm::mat4 view = glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);
        glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "view"), 1, GL_FALSE, glm::value_ptr(view));

        // Model matrix
        glm::mat4 model = glm::mat4(1.0f);
        glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "model"), 1, GL_FALSE, glm::value_ptr(model));

        // Draw the table
        glBindTexture(GL_TEXTURE_2D, tableTexture);
        glBindVertexArray(VAO);
        glDrawElements(GL_TRIANGLES, 12, GL_UNSIGNED_INT, 0);

        glBindTexture(GL_TEXTURE_2D, legsTexture);
        glDrawElements(GL_TRIANGLES, 24, GL_UNSIGNED_INT, (void*)(12 * sizeof(unsigned int)));

        //set up the model matrix for the plate
        glm::mat4 plateModel = glm::mat4(1.0f);
        plateModel = glm::translate(plateModel, glm::vec3(0.0f, h, 0.0f)); // Translate the plate along the y-axis to raise it
        plateModel = glm::scale(plateModel, glm::vec3(a, 1.0f, b)); // Scale the plate to match the ellipse
        glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "model"), 1, GL_FALSE, glm::value_ptr(plateModel));

        // Bind the plate texture before drawing the plate
        glBindTexture(GL_TEXTURE_2D, plateTexture);

        // Draw the plate
        glBindVertexArray(plateVAO);
        glDrawArrays(GL_TRIANGLE_FAN, 0, numSegments + 1);

        // Check and call events and swap the buffers
        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    // Cleanup
    glDeleteVertexArrays(1, &VAO);
    glDeleteBuffers(1, &VBO);
    glDeleteBuffers(1, &EBO);
    glDeleteProgram(shaderProgram);
    glfwTerminate();
    return 0;
}
